//
// Created by weihs on 10/06/2021.
//

#ifndef INC_12_EQUATION_OF_MOTION_H
#define INC_12_EQUATION_OF_MOTION_H
#include "main.h"

void evolve_state(state*, int, long double);
void evolve_state_parallel(state*, int, long double);

#endif
