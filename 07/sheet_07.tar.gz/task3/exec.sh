cd ..
make clean
make
cd task3
./task3
